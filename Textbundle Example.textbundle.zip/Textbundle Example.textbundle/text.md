# Textbundle Example

This is a simple example of a textbundle package. The following paragraph contains an example of a referenced image using the embedding code `![](assets/textbundle.png)`.

![][image-1]

[image-1]:	assets/textbundle.png